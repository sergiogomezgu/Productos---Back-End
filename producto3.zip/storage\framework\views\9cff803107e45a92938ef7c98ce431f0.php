<?php $__env->startSection('title', 'Hoteles'); ?>
<?php $__env->startSection('header', 'Listado de Hoteles'); ?>

<?php $__env->startSection('content'); ?>
    <a href="<?php echo e(route('admin.hotels.create')); ?>" class="bg-blue-600 text-white px-4 py-2 rounded">
        Nuevo hotel
    </a>

    <table class="w-full mt-6 bg-white shadow rounded">
        <thead>
            <tr class="border-b">
                <th class="p-3 text-left">ID</th>
                <th class="p-3 text-left">Nombre</th>
                <th class="p-3 text-left">Ciudad</th>
                <th class="p-3 text-left">Zona</th>
                <th class="p-3 text-left">Comisión</th>
                <th class="p-3 text-left">Acciones</th>
            </tr>
        </thead>

        <tbody>
            <?php $__currentLoopData = $hotels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hotel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="border-b">
                    <td class="p-3"><?php echo e($hotel->id); ?></td>
                    <td class="p-3"><?php echo e($hotel->name); ?></td>
                    <td class="p-3"><?php echo e($hotel->city); ?></td>
                    <td class="p-3"><?php echo e($hotel->zona ?? '-'); ?></td>
                    <td class="p-3"><?php echo e(number_format($hotel->comision_porcentaje ?? 0, 2)); ?>%</td>

                    <td class="p-3 flex gap-3">
                        <a href="<?php echo e(route('admin.hotels.edit', $hotel)); ?>" class="text-blue-600">
                            Editar
                        </a>

                        <form action="<?php echo e(route('admin.hotels.destroy', $hotel)); ?>"
                              method="POST"
                              onsubmit="return confirm('¿Seguro que deseas eliminar este hotel?')">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button class="text-red-600">
                                Eliminar
                            </button>
                        </form>
                        
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/html/resources/views/admin/hotels/index.blade.php ENDPATH**/ ?>