<?php $__env->startSection('title', 'Reservas'); ?>
<?php $__env->startSection('header', 'Listado de Reservas'); ?>

<?php $__env->startSection('content'); ?>
    <a href="<?php echo e(route('admin.reservations.create')); ?>" class="bg-blue-600 text-white px-4 py-2 rounded">
        Nueva reserva
    </a>
<form method="GET" action="<?php echo e(route('admin.reservations.index')); ?>" class="mb-6 flex gap-4 items-end">

    <div>
        <label class="block text-sm font-semibold mb-1">Hotel</label>
        <select name="hotel_id" class="border rounded px-3 py-2">
            <option value="">Todos</option>
            <?php $__currentLoopData = $hotels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hotel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($hotel->id); ?>" <?php echo e(request('hotel_id') == $hotel->id ? 'selected' : ''); ?>>
                    <?php echo e($hotel->name); ?>

                </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>

    <div>
        <label class="block text-sm font-semibold mb-1">Estado</label>
        <select name="status" class="border rounded px-3 py-2">
            <option value="">Todos</option>
            <option value="pendiente" <?php echo e(request('status') == 'pendiente' ? 'selected' : ''); ?>>Pendiente</option>
            <option value="confirmada" <?php echo e(request('status') == 'confirmada' ? 'selected' : ''); ?>>Confirmada</option>
            <option value="cancelada" <?php echo e(request('status') == 'cancelada' ? 'selected' : ''); ?>>Cancelada</option>
        </select>
    </div>

    <div>
        <label class="block text-sm font-semibold mb-1">Desde</label>
        <input type="date" name="from" value="<?php echo e(request('from')); ?>" class="border rounded px-3 py-2">
    </div>

    <div>
        <label class="block text-sm font-semibold mb-1">Hasta</label>
        <input type="date" name="to" value="<?php echo e(request('to')); ?>" class="border rounded px-3 py-2">
    </div>

    <button class="bg-blue-600 text-white px-4 py-2 rounded">Filtrar</button>
    <a href="<?php echo e(route('admin.reservations.index')); ?>" class="bg-gray-300 px-4 py-2 rounded">Limpiar</a>
</form>

    <table class="w-full mt-6 bg-white shadow rounded">
        <thead>
            <tr class="border-b">
                <th class="p-3 text-left">ID</th>
                <th class="p-3 text-left">Hotel</th>
                <th class="p-3 text-left">Usuario</th>
                <th class="p-3 text-left">Entrada</th>
                <th class="p-3 text-left">Salida</th>
                <th class="p-3 text-left">Huéspedes</th>
                <th class="p-3 text-left">Estado</th>
                <th class="p-3 text-left">Acciones</th>
            </tr>
        </thead>

        <tbody>
            <?php $__currentLoopData = $reservations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reservation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="border-b">
                    <td class="p-3"><?php echo e($reservation->id); ?></td>
                    <td class="p-3"><?php echo e($reservation->hotel->name); ?></td>
                    <td class="p-3">
                        <?php echo e($reservation->hotelUser?->name ?? '—'); ?>

                    </td>
                    <td class="p-3"><?php echo e($reservation->check_in); ?></td>
                    <td class="p-3"><?php echo e($reservation->check_out); ?></td>
                    <td class="p-3"><?php echo e($reservation->guests); ?></td>
                    <td class="p-3 capitalize"><?php echo e($reservation->status); ?></td>

                    <td class="p-3 flex gap-3">
                        <a href="<?php echo e(route('admin.reservations.edit', $reservation)); ?>" class="text-blue-600">
                            Editar
                        </a>

                        <form action="<?php echo e(route('admin.reservations.destroy', $reservation)); ?>"
                              method="POST"
                              onsubmit="return confirm('¿Seguro que deseas eliminar esta reserva?')">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button class="text-red-600">Eliminar</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/html/resources/views/admin/reservations/index.blade.php ENDPATH**/ ?>