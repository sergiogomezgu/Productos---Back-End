<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Panel Admin - <?php echo $__env->yieldContent('title'); ?></title>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?></head>
<body class="bg-gray-100">
    <div class="min-h-screen flex">
        <aside class="w-64 bg-gray-900 text-white p-4">
            <h1 class="text-xl font-bold mb-6">Admin</h1>
            <nav class="space-y-2">
                <a href="<?php echo e(route('admin.dashboard')); ?>" class="block hover:bg-gray-700 px-3 py-2 rounded">
                    Dashboard
                </a>
                <a href="<?php echo e(route('admin.hotels.index')); ?>" class="block hover:bg-gray-700 px-3 py-2 rounded">
                    Hoteles
                </a>
               <a href="<?php echo e(route('admin.hotel_users.index')); ?>" class="block hover:bg-gray-700 px-3 py-2 rounded">
    Usuarios hotel
</a>
                <a href="<?php echo e(route('admin.reservations.index')); ?>" class="block hover:bg-gray-700 px-3 py-2 rounded">
    Reservas
</a>
<a href="<?php echo e(route('admin.reservations.calendar')); ?>" class="block hover:bg-gray-700 px-3 py-2 rounded">
    Calendario
</a>
                <a href="<?php echo e(route('admin.commissions.index')); ?>" class="block hover:bg-gray-700 px-3 py-2 rounded">
                    Comisiones
                </a>
            </nav>
        </aside>

        <main class="flex-1 p-6">
            <header class="flex justify-between items-center mb-6">
                <h2 class="text-2xl font-semibold">
                    <?php echo $__env->yieldContent('header', 'Panel de administración'); ?>
                </h2>
                <form method="POST" action="<?php echo e(route('logout')); ?>">
                    <?php echo csrf_field(); ?>
                    <button class="text-sm text-red-600 hover:underline">
                        Cerrar sesión
                    </button>
                </form>
            </header>

            <section>
                <?php if(session('success')): ?>
    <div class="bg-green-100 text-green-800 px-4 py-2 rounded mb-4">
        <?php echo e(session('success')); ?>

    </div>
<?php endif; ?>
                <?php echo $__env->yieldContent('content'); ?>
            </section>
        </main>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/fullcalendar@6.1.8/index.global.min.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/fullcalendar@6.1.8/index.global.min.js"></script>

<?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html>
<?php /**PATH /var/www/html/resources/views/layouts/admin.blade.php ENDPATH**/ ?>