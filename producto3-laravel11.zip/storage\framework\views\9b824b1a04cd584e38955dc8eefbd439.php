<?php $__env->startSection('title', 'Editar Hotel'); ?>
<?php $__env->startSection('header', 'Editar hotel'); ?>

<?php $__env->startSection('content'); ?>
    <div class="bg-white shadow rounded p-6 max-w-xl">
        <form action="<?php echo e(route('admin.hotels.update', $hotel)); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>

            <div class="mb-4">
                <label class="block font-semibold mb-1">Nombre</label>
                <input type="text" name="name" value="<?php echo e($hotel->name); ?>" class="w-full border rounded px-3 py-2" required>
            </div>

            <div class="mb-4">
                <label class="block font-semibold mb-1">Ciudad</label>
                <input type="text" name="city" value="<?php echo e($hotel->city); ?>" class="w-full border rounded px-3 py-2">
            </div>

            <div class="mb-4">
                <label class="block font-semibold mb-1">Dirección</label>
                <input type="text" name="address" value="<?php echo e($hotel->address); ?>" class="w-full border rounded px-3 py-2">
            </div>

            <div class="mb-4">
                <label class="block font-semibold mb-1">Teléfono</label>
                <input type="text" name="phone" value="<?php echo e($hotel->phone); ?>" class="w-full border rounded px-3 py-2">
            </div>

            <div class="mb-4">
                <label class="block font-semibold mb-1">Email</label>
                <input type="email" name="email" value="<?php echo e($hotel->email); ?>" class="w-full border rounded px-3 py-2">
            </div>

            <div class="mb-4">
                <label class="block font-semibold mb-1">Descripción</label>
                <textarea name="description" class="w-full border rounded px-3 py-2" rows="4"><?php echo e($hotel->description); ?></textarea>
            </div>

            <div class="mb-4">
                <label class="block font-semibold mb-1">Zona</label>
                <select name="zona" class="w-full border rounded px-3 py-2">
                    <option value="">Seleccionar zona</option>
                    <option value="Norte" <?php echo e($hotel->zona == 'Norte' ? 'selected' : ''); ?>>Norte</option>
                    <option value="Sur" <?php echo e($hotel->zona == 'Sur' ? 'selected' : ''); ?>>Sur</option>
                    <option value="Este" <?php echo e($hotel->zona == 'Este' ? 'selected' : ''); ?>>Este</option>
                    <option value="Oeste" <?php echo e($hotel->zona == 'Oeste' ? 'selected' : ''); ?>>Oeste</option>
                    <option value="Centro" <?php echo e($hotel->zona == 'Centro' ? 'selected' : ''); ?>>Centro</option>
                </select>
            </div>

            <div class="mb-4">
                <label class="block font-semibold mb-1">Comisión (%)</label>
                <input type="number" name="comision_porcentaje" step="0.01" min="0" max="100" value="<?php echo e($hotel->comision_porcentaje ?? 0); ?>" class="w-full border rounded px-3 py-2">
                <small class="text-gray-500">Porcentaje de comisión que recibirá el hotel por cada reserva</small>
            </div>

            <button class="bg-blue-600 text-white px-4 py-2 rounded">
                Actualizar hotel
            </button>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/html/resources/views/admin/hotels/edit.blade.php ENDPATH**/ ?>