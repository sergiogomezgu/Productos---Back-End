<?php $__env->startSection('title', 'Dashboard'); ?>
<?php $__env->startSection('header', 'Panel de control'); ?>

<?php $__env->startSection('content'); ?>

    <div class="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">

        <div class="bg-white p-6 shadow rounded">
            <h3 class="text-gray-600 text-sm">Hoteles</h3>
            <p class="text-3xl font-bold"><?php echo e($totalHotels); ?></p>
        </div>

        <div class="bg-white p-6 shadow rounded">
            <h3 class="text-gray-600 text-sm">Usuarios de hotel</h3>
            <p class="text-3xl font-bold"><?php echo e($totalHotelUsers); ?></p>
        </div>

        <div class="bg-white p-6 shadow rounded">
            <h3 class="text-gray-600 text-sm">Reservas</h3>
            <p class="text-3xl font-bold"><?php echo e($totalReservations); ?></p>
        </div>

    </div>

    <div class="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">

        <div class="bg-yellow-100 p-6 shadow rounded">
            <h3 class="text-gray-700 text-sm">Pendientes</h3>
            <p class="text-3xl font-bold"><?php echo e($pending); ?></p>
        </div>

        <div class="bg-green-100 p-6 shadow rounded">
            <h3 class="text-gray-700 text-sm">Confirmadas</h3>
            <p class="text-3xl font-bold"><?php echo e($confirmed); ?></p>
        </div>

        <div class="bg-red-100 p-6 shadow rounded">
            <h3 class="text-gray-700 text-sm">Canceladas</h3>
            <p class="text-3xl font-bold"><?php echo e($cancelled); ?></p>
        </div>

        <div class="bg-blue-100 p-6 shadow rounded">
            <h3 class="text-gray-700 text-sm">Comisiones este mes</h3>
            <p class="text-2xl font-bold text-blue-800">€<?php echo e(number_format($totalComisionesMes, 2)); ?></p>
        </div>

    </div>

    <div class="bg-white p-6 shadow rounded">
        <h3 class="text-xl font-semibold mb-4">Últimas reservas</h3>

        <table class="w-full bg-white">
            <thead>
                <tr class="border-b">
                    <th class="p-3 text-left">ID</th>
                    <th class="p-3 text-left">Hotel</th>
                    <th class="p-3 text-left">Usuario</th>
                    <th class="p-3 text-left">Entrada</th>
                    <th class="p-3 text-left">Salida</th>
                    <th class="p-3 text-left">Estado</th>
                </tr>
            </thead>

            <tbody>
                <?php $__currentLoopData = $latestReservations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reservation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="border-b">
                        <td class="p-3"><?php echo e($reservation->id); ?></td>
                        <td class="p-3"><?php echo e($reservation->hotel->name); ?></td>
                        <td class="p-3"><?php echo e($reservation->hotelUser?->name ?? '—'); ?></td>
                        <td class="p-3"><?php echo e($reservation->check_in); ?></td>
                        <td class="p-3"><?php echo e($reservation->check_out); ?></td>
                        <td class="p-3 capitalize"><?php echo e($reservation->status); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<div class="bg-white p-6 shadow rounded mb-8">
    <h3 class="text-xl font-semibold mb-4">Reservas por estado</h3>
    <canvas id="reservasChart"></canvas>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    const ctx = document.getElementById('reservasChart');

    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: ['Pendientes', 'Confirmadas', 'Canceladas'],
            datasets: [{
                label: 'Número de reservas',
                data: [<?php echo e($pending); ?>, <?php echo e($confirmed); ?>, <?php echo e($cancelled); ?>],
                backgroundColor: [
                    'rgba(255, 206, 86, 0.6)',
                    'rgba(75, 192, 192, 0.6)',
                    'rgba(255, 99, 132, 0.6)'
                ],
                borderColor: [
                    'rgba(255, 206, 86, 1)',
                    'rgba(75, 192, 192, 1)',
                    'rgba(255, 99, 132, 1)'
                ],
                borderWidth: 1
            }]
        },
        options: {
            scales: {
                y: { beginAtZero: true }
            }
        }
    });
</script>
<?php $__env->stopPush(); ?>


<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/html/resources/views/admin/dashboard/index.blade.php ENDPATH**/ ?>